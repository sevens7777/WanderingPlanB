export = isObject;

declare function isObject(val: any): boolean;

declare namespace isObject {}
