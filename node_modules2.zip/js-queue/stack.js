const Stack=require('easy-stack');

module.exports = Stack;
